import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { ContentComponent } from './content/content.component';
import { LogInComponent } from './log-in/log-in.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { ContentLayoutComponent } from './layouts/content-layout/content-layout.component';
import { LogInLayoutComponent } from './layouts/log-in-layout/log-in-layout.component';
import { SignUpLayoutComponent } from './layouts/sign-up-layout/sign-up-layout.component';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MatDatepickerModule, MatInputModule, MatNativeDateModule } from '@angular/material';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatCheckboxModule} from '@angular/material/checkbox';
//import { SearchResultsLayoutComponent } from './layouts/search-results-layout/search-results-layout.component';
// import { SearchResultsComponent } from './search-results/search-results.component';
import {MatButtonModule} from '@angular/material/button';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { UserLayoutComponent } from './layouts/user-layout/user-layout.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { MyProfileLayoutComponent } from './layouts/my-profile-layout/my-profile-layout.component';
import { UserCurrentComponent } from './user-current/user-current.component';
import { UserCurrentLayoutComponent } from './layouts/user-current-layout/user-current-layout.component';
import { UserCompletedComponent } from './user-completed/user-completed.component';
import { UserCompletedLayoutComponent } from './layouts/user-completed-layout/user-completed-layout.component';
import { UserSettingsComponent } from './user-settings/user-settings.component';
import { UserSettingsLayoutComponent } from './layouts/user-settings-layout/user-settings-layout.component';
import { MentorLoginComponent } from './mentor-login/mentor-login.component';
import { MentorLoginLayoutComponent } from './layouts/mentor-login-layout/mentor-login-layout.component';
import { MentorProfileComponent } from './mentor-profile/mentor-profile.component';
import { MentorProfileLayoutComponent } from './layouts/mentor-profile-layout/mentor-profile-layout.component';
import { MentorMyProfileComponent } from './mentor-my-profile/mentor-my-profile.component';
import { MentorMyProfileLayoutComponent } from './layouts/mentor-my-profile-layout/mentor-my-profile-layout.component';
import { MentorCurrentComponent } from './mentor-current/mentor-current.component';
import { MentorCurrentLayoutComponent } from './layouts/mentor-current-layout/mentor-current-layout.component';
import { MentorCompletedComponent } from './mentor-completed/mentor-completed.component';
import { MentorCompletedLayoutComponent } from './layouts/mentor-completed-layout/mentor-completed-layout.component';
import { Navbar1Component } from './navbar1/navbar1.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminNavbarComponent } from './admin-navbar/admin-navbar.component';
import { EditPermissionComponent } from './edit-permission/edit-permission.component';
import { AdminNavbarLayoutComponent } from './layouts/admin-navbar-layout/admin-navbar-layout.component';
import { AdminLoginLayoutComponent } from './layouts/admin-login-layout/admin-login-layout.component';
import { AdminPaymentsComponent } from './admin-payments/admin-payments.component';
import { AdminEditPermissionLayoutComponent } from './layouts/admin-edit-permission-layout/admin-edit-permission-layout.component';

// import { SearchResultsComponent } from './search-results/search-results.component';
// import { SearchResultLayoutComponent } from './layouts/search-result-layout/search-result-layout.component';

import { SearchresultsComponent } from './searchresults/searchresults.component';
import { SearchresultsLayoutComponent } from './layouts/searchresults-layout/searchresults-layout.component';
import { CreditcardComponent } from './creditcard/creditcard.component';
import { CreditLayoutComponent } from './layouts/credit-layout/credit-layout.component';

import { HttpClientModule } from '@angular/common/http';

import {MatBadgeModule} from '@angular/material/badge';
import {MatIconModule} from'@angular/material/icon';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { AdminPaymentsLayoutComponent } from './layouts/admin-payments-layout/admin-payments-layout.component';
import { AdminDisplayReportsComponent } from './admin-display-reports/admin-display-reports.component';
import { AdminDisplayReportsLayoutComponent } from './layouts/admin-display-reports-layout/admin-display-reports-layout.component';
import { MentorSettingsComponent } from './mentor-settings/mentor-settings.component';
import { MentorSettingsLayoutComponent } from './layouts/mentor-settings-layout/mentor-settings-layout.component';

import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { MentorSignupLayoutComponent } from './layouts/mentor-signup-layout/mentor-signup-layout.component';
import { FooterLayoutComponent } from './layouts/footer-layout/footer-layout.component';
import { FootComponent } from './foot/foot.component';
import { DisplayTechListComponent } from './display-tech-list/display-tech-list.component';



@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    ContentComponent,
    LogInComponent,
    SignUpComponent,
    ContentLayoutComponent,
    LogInLayoutComponent,
    SignUpLayoutComponent,
    //SearchResultsLayoutComponent,
    UserProfileComponent,
    UserLayoutComponent,
    MyProfileComponent,
    UserCurrentComponent,
    MyProfileLayoutComponent,
    UserCurrentLayoutComponent,
    UserCompletedComponent,
    UserCompletedLayoutComponent,
    UserSettingsComponent,
    UserSettingsLayoutComponent,
    MentorLoginComponent,
    MentorLoginLayoutComponent,
    MentorProfileComponent,
    MentorProfileLayoutComponent,
    MentorMyProfileComponent,
    MentorMyProfileLayoutComponent,
    
    MentorCurrentComponent,
    MentorCurrentLayoutComponent,
    MentorCompletedComponent,
    MentorCompletedLayoutComponent,
    Navbar1Component,
    AdminLoginComponent,
    AdminNavbarComponent,
    EditPermissionComponent,
    AdminNavbarLayoutComponent,
    AdminLoginLayoutComponent,
    AdminPaymentsComponent,
    AdminEditPermissionLayoutComponent,
    
    SearchresultsComponent,
    SearchresultsLayoutComponent,
    CreditcardComponent,
    CreditLayoutComponent,
    AdminPaymentsLayoutComponent,
    AdminDisplayReportsComponent,
    AdminDisplayReportsLayoutComponent,
    MentorSettingsComponent,
    MentorSettingsLayoutComponent,
  
    MentorSignupComponent,
    MentorSignupLayoutComponent,
    FooterLayoutComponent,
    FootComponent,
    DisplayTechListComponent,
    
    
    
   
    // SearchResultsComponent,
    // SearchResultLayoutComponent
    
  
    // SearchResultsComponent
    
   
   
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule,
    MatAutocompleteModule,
    FormsModule,
    ReactiveFormsModule,
    MatCheckboxModule,
    MatButtonModule,
    HttpClientModule,
    RouterModule,
    MatBadgeModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    MatSlideToggleModule,
  ],
  providers: [],
  
  bootstrap: [AppComponent]
})
export class AppModule { }