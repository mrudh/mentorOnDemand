import { Component, OnInit } from '@angular/core';
import { ValidationMentorService,Mentor } from '../validation-mentor.service';
@Component({
  selector: 'app-edit-permission',
  templateUrl: './edit-permission.component.html',
  styleUrls: ['./edit-permission.component.scss']
})
export class EditPermissionComponent implements OnInit {
  constructor(private adminValidationService:ValidationMentorService) { }
  user=[];
  mentor=[];
  mentorDetails;
  userDetails;
  i;
  ngOnInit() {
    this.userDetails= this.adminValidationService.getUserDetails().subscribe((data) => {
      var index=0;
      for(this.i=0;this.i<Object.keys(data).length;this.i++){
        this.user[index]=data[this.i];
        index++;
      }
   
})
this.mentorDetails= this.adminValidationService.getMentorDetails().subscribe((data) => {
  var index=0;
  for(this.i=0;this.i<Object.keys(data).length;this.i++){
    this.mentor[index]=data[this.i];
    index++;
  }

})
  }
  onBlock(event,username){
    this.adminValidationService.blockUser(username).subscribe();
  }
  onUnblock(event,username){
    this.adminValidationService.unblockUser(username).subscribe();
  }
  onBlockMentor(event,username){
    this.adminValidationService.blockMentor(username).subscribe();
  }
  onUnblockMentor(event,username){
    this.adminValidationService.unblockMentor(username).subscribe();
  }

}