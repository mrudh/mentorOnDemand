import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorMyProfileComponent } from './mentor-my-profile.component';

describe('MentorMyProfileComponent', () => {
  let component: MentorMyProfileComponent;
  let fixture: ComponentFixture<MentorMyProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorMyProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorMyProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
