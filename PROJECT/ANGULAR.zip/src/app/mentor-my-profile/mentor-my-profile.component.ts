import { Component, OnInit } from '@angular/core';
import { ValidationMentorService } from '../validation-mentor.service';
import { FormGroup, FormControl,Validators,FormBuilder } from '@angular/forms';
@Component({
  selector: 'app-mentor-my-profile',
  templateUrl: './mentor-my-profile.component.html',
  styleUrls: ['./mentor-my-profile.component.scss']
})
export class MentorMyProfileComponent implements OnInit {

  user_name;
  first_name;
ment_skills;
  constructor(private formBuilder: FormBuilder,private mentorService:ValidationMentorService) { }

  ngOnInit() {
  this.user_name=this.mentorService.username;
  this.first_name=this.mentorService.firstName;
  this.ment_skills=this.mentorService.skills;
  }

}
