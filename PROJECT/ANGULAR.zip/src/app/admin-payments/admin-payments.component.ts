import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ValidationMentorService,Mentor } from '../validation-mentor.service';
@Component({
  selector: 'app-admin-payments',
  templateUrl: './admin-payments.component.html',
  styleUrls: ['./admin-payments.component.scss']
})
export class AdminPaymentsComponent implements OnInit {

  constructor(private route:ActivatedRoute,private validationService:ValidationMentorService) { }

  // user=[];
  mentor=[];
  mentorDetails;
  userDetails;
  i;
  ngOnInit() {
//     this.userDetails= this.validationService.getUserDetails().subscribe((data) => {
//       var index=0;
//       for(this.i=0;this.i<Object.keys(data).length;this.i++){
//         this.user[index]=data[this.i];
//         index++;
//       }
   
// })
this.mentorDetails= this.validationService.getMentorDetails().subscribe((data) => {
  var index=0;
  for(this.i=0;this.i<Object.keys(data).length;this.i++){
    this.mentor[index]=data[this.i];
    index++;
  }

})
  }

}
