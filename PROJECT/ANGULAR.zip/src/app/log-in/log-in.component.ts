import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validators,FormBuilder, EmailValidator } from '@angular/forms';
import { Router } from '@angular/router';
import { ValidationMentorService, User } from '../validation-mentor.service';
@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.scss']
})
export class LogInComponent implements OnInit {

  LogInForm: FormGroup;
    submitted = false;
      ismatch=false;
  constructor(private formBuilder: FormBuilder, private validationUserService:ValidationMentorService,private route:Router,) {
  
  }
userDetails;
model:any={
  username:String,
  password:String,
  errorMessage:String,
  validStatus:Boolean,
}

  ngOnInit() {
    this.initlogInForm();
   this.model.username="";
   this.model.password="";
   this.model.errorMessage="";
   this.model.invalidStatus=false;
   
  }
  index;
  i;
  uname;
flag;
  details;
  onSubmit() {
    this.submitted = true;
    this.userDetails = this.validationUserService.getUserDetails().subscribe((data:User)=> {
     for(this.i=0;this.i<Object.keys(data).length;this.i++) {
           if(data[this.i].username==this.model.username && data[this.i].password==this.model.password) {
        // this.route.navigate(['/user']);
        this.uname=data[this.i].username;
       this.validationUserService.username=this.uname;
       this.validationUserService.firstName=data[this.i].firstName;
       this.flag=true;
       break;
      }
      else {
        this.flag=false;
      }
    }
    if(this.flag==true)
    this.route.navigate(['/user']);
      else {
        this.model.username="";
        this.model.password="";
        this.model.errorMessage="username or password is incorrect";
        this.model.invalidStatus=true;
      }
     });
   }
  //this.submitted = true;
  // this.validationUserService.getUserDetails().subscribe((data => {
  //   this.details=data;
  //     for(this.index=0;this.index<(this.details.length);this.index++){
  //       if(this.details[this.index].username==this.model.username&& this.details[this.index].password==this.model.password) {
          
  //         this.ismatch=true;
  //         break;
  //       } else{
  //         this.ismatch=false;
  //       }
  //     }
  //     if(this.ismatch==true)
  //       this.route.navigate(['/user']);
  //     else {
  //         this.model.username="";
  //         this.model.password="";
  //         this.model.errorMessage="username or password is incorrect";
  //         this.model.invalidStatus=true;
  //       }
  //      }));
  get f() { return this.LogInForm.controls; }

  private initlogInForm() {
    this.LogInForm =this.formBuilder.group({
      username: new FormControl('',[Validators.required,Validators.email]),
      Password : new FormControl('',[Validators.required,Validators.minLength(6)])
    });
  }
  }


 

