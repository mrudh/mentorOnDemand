import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ValidationAdminService {
  admins=[];
  constructor(  private http: HttpClient) { }
  getAdminDetails() {
    return this.http.get('/assets/adminCredentials.json');
  }

}
  export interface ACredentials{
    name:String;
    passw:String;
   
  }