import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-display-reports',
  templateUrl: './admin-display-reports.component.html',
  styleUrls: ['./admin-display-reports.component.scss']
})
export class AdminDisplayReportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
