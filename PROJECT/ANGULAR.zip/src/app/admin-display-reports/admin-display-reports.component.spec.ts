import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminDisplayReportsComponent } from './admin-display-reports.component';

describe('AdminDisplayReportsComponent', () => {
  let component: AdminDisplayReportsComponent;
  let fixture: ComponentFixture<AdminDisplayReportsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminDisplayReportsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminDisplayReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
