import { TestBed } from '@angular/core/testing';

import { ValidationMentorService } from './validation-mentor.service';

describe('ValidationMentorService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ValidationMentorService = TestBed.get(ValidationMentorService);
    expect(service).toBeTruthy();
  });
});
