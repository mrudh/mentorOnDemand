import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validators,FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import {User} from '../validation-mentor.service';
import { ValidationMentorService } from '../validation-mentor.service';
@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss']
})

export class SignUpComponent implements OnInit {
  SignUpForm: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder,private router:Router,private userService:ValidationMentorService) { }

  ngOnInit() {
    this.initsignUpForm();
  }
  user:User=new User();
  onSubmit() {
    this.user=new User();
    this.user.username=this.SignUpForm.get('Email').value;
this.user.password=this.SignUpForm.get('Password').value;
this.user.firstName=this.SignUpForm.get('FirstName').value;
// this.user.fee_status=this.SignUpForm.get('courseName').value;
    this.submitted = true;
    this.save();
    if(this.SignUpForm.valid)
      this.router.navigate(['/log-in'])
}

  get f() { return this.SignUpForm.controls; }
  
  save(){
    this.userService.addUserDetails(this.user).subscribe(data=>console.log(data),error=>console.log(error));
    //this.mentor=new Mentor();
    
  }



  private initsignUpForm() {
    this.SignUpForm =this.formBuilder.group({
      
      FirstName : new FormControl(null,Validators.required),
      LastName : new FormControl(null,Validators.required),
      Email: new FormControl('',[Validators.required,Validators.email]),
    Password : new FormControl('',[Validators.required,Validators.minLength(6)])
     
    });
}
}
