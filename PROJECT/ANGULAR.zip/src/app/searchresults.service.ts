import { Injectable } from '@angular/core';
import {Router} from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class SearchresultsService {

  constructor() { }

  searchTechnology(value,router:Router) {
    router.navigate(['techs',value]);
  }
}
