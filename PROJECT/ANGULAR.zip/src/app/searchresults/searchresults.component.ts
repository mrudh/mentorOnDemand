import { Component, OnInit } from '@angular/core';
import { techs } from '../tech';
import { ActivatedRoute } from '@angular/router';
import { ValidationMentorService,Mentor } from '../validation-mentor.service';


@Component({
  selector: 'app-searchresults',
  templateUrl: './searchresults.component.html',
  styleUrls: ['./searchresults.component.scss']
})
export class SearchresultsComponent implements OnInit {

  constructor(private route:ActivatedRoute,private validationMentorService:ValidationMentorService) {

   }
  
  tech=[];
  mname;
  i;
  gst;
  
  mentorDetails:any;
  courseName;
  startCourseDate;
  endCourseDate;

  ngOnInit() {
     this.route.paramMap.subscribe(params => {
       console.log(params.get('techId')+"====");
       this.courseName=params.get('techId');
       this.startCourseDate=this.validationMentorService.startDate;
       this.endCourseDate=this.validationMentorService.endDate;
       this.mentorDetails=this.validationMentorService.getSearchResults(this.courseName).subscribe((data:Mentor)=>{
        var index=0;
    for(this.i=0;this.i<Object.keys(data).length;this.i++) {
      console.log("=>"+data[this.i].fees);
      this.gst=25;
      this.tech[index]=data[this.i];
      index++;
    }
    });
  });
  }
  
  }
 



