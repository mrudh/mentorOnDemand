import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validators,FormBuilder, EmailValidator } from '@angular/forms';
import { ValidationMentorService, Mentor } from '../validation-mentor.service';
//import {MCredentials} from '../validation-mentor.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mentor-login',
  templateUrl: './mentor-login.component.html',
  styleUrls: ['./mentor-login.component.scss']
})
export class MentorLoginComponent implements OnInit {

  MentorLogInForm: FormGroup;

    submitted = false;
    match=false;

  constructor(private formBuilder: FormBuilder, private validationMentorService:ValidationMentorService,private route:Router,) {
  
  }

  mentorDetails;
model:any={
username:String,
password:String,
errorMessage:String,
validStatus:Boolean
};

  ngOnInit() {
    this.initmentorlogInForm();
   this.model.username="";
   this.model.password="";
   this.model.errorMessage="";
   this.model.invalidStatus=false;
  // this.submitted=false;
  }
  index;
  details;
  uname;
  flag:Boolean;
  onSubmit() {
    this.submitted = true;
   this.validationMentorService.getMentorDetails().subscribe((data => {
      
      // for(this.i=0;this.i<Object.keys(data).length;this.i++) {
      
      //   if(data[this.i].username==this.model.username && data[this.i].password==this.model.password) {
         
      //    this.flag=true;
      //    break;
      //   }
      //   else {
      //     this.flag=false;
      //   }
      // }
      this.details=data;
      for(this.index=0;this.index<(this.details.length);this.index++){
        if(this.details[this.index].username==this.model.username&& this.details[this.index].password==this.model.password) {
          this.uname=data[this.index].username;
       this.validationMentorService.username=this.uname;
       this.validationMentorService.firstName=data[this.index].firstName;
          this.match=true;
          break;
        } else{
          this.match=false;
        }
      }

  
      if(this.match==true)
      this.route.navigate(['/mentor-profile']);
        else {
          this.model.username="";
          this.model.password="";
          this.model.errorMessage="username or password is incorrect";
          this.model.invalidStatus=true;
        }
       }));
     
  }


  get f() { return this.MentorLogInForm.controls; }

private initmentorlogInForm() {
  this.MentorLogInForm =this.formBuilder.group({
    username: new FormControl('',[Validators.required,Validators.email]),
    Password : new FormControl('',[Validators.required,Validators.minLength(6)])
  });
}


}
