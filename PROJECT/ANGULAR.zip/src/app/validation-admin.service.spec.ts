import { TestBed } from '@angular/core/testing';

import { ValidationAdminService } from './validation-admin.service';

describe('ValidationAdminService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ValidationAdminService = TestBed.get(ValidationAdminService);
    expect(service).toBeTruthy();
  });
});
