import { Component, OnInit } from '@angular/core';

import { SearchresultsService } from '../searchresults.service';
import { FormControl,FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss']
})
export class UserProfileComponent implements OnInit {

  myControl = new FormControl();
  options: string[] = ['Angular',  'Dotnet',  'Java','Python'];
 
  constructor(private route:ActivatedRoute,private router:Router,private searchService:SearchresultsService) { }
searchForm;
  ngOnInit() {
    this.searchForm=new FormGroup({myControl:new FormControl("")});
  }
  OnClickSearch(data){
    this.myControl=data.myControl;
    this.searchService.searchTechnology(this.myControl,this.router);
  }

}
