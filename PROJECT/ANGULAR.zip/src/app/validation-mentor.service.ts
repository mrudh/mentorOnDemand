import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ValidationMentorService {
mentors=[];



  constructor(  private http: HttpClient) { }
  getMentorDetails():Observable<Mentor> {
    //return this.http.get<Mentor>(`${this.baseUrl}`+'mentorsList');
    return this.http.get<Mentor>('http://localhost:8761/mentor/mentorsList');
  }

  addMentorDetails(mentor:Object):Observable<object> {
    console.log(mentor);
    
    return this.http.post('http://localhost:8761/mentor/addMentor',mentor);
    // return this.http.post(`${this.baseUrl}`+'addMentor',mentor);
  }

  //getSearchResults(courseName,startDate:Date,endDate:Date):Observable<Mentor>{
  getSearchResults(courseName:String):Observable<Mentor> {
    
    return this.http.get<Mentor>('http://localhost:8761/mentor/mentorsList');
    //return this.http.get<Mentor>(`${this.baseUrl}`+'mentorsList/'+`${courseName}`+'/'+`${startDate}`+'/'+`${endDate}`);
  }

  getUserDetails():Observable<User> {
    //return this.http.get<User>(`${this.baseUrl}`+'usersList');
    return this.http.get<User>('http://localhost:8761/user/usersList');
  }
  addUserDetails(user:Object):Observable<object> {
    console.log(user);
    return this.http.post('http://localhost:8761/user/addUser',user);
   // return this.http.post(`${this.baseUrl}`+'addUser',user);
  }
  addCalendarDetails(mentorCalendar:Object,username:String):Observable<object> {
    console.log(mentorCalendar);
   return this.http.post('http://localhost:8761/addMentor/addCalendar/'+`${username}`,mentorCalendar);
   // return this.http.post<MentorCalendar>(`${this.baseUrl}`+'addMentor/addCalendar/'+`${username}`,mentorCalendar);
  }
  // getMentorsDetails(courseName:String,startDate):Observable<Mentor>{
  //   return this.http.get<Mentor>(`${this.baseUrl}`+'/mentorsList/'+`${courseName}`+`${startDate}`);
  // }
// SKILLS SKILLS SKILLS
  // addSkills(skill:Object,username):Observable<object>{
  //   console.log(username+"=username");
  //   console.log("skillName="+skill);
  //   return this.http.post<MentorSkills>(`${this.baseUrl}`+'addMentor/addSkill/'+`${username}`,skill);
  // }
  // getMentorSkills(username){
  //   return this.http.get(`${this.baseUrl}`+'getMentorSkills/'+`${username}`);
  // }
  blockUser(username:String):Observable<object>{
    return this.http.get('http://localhost:8761/user/userDetailsBlock/' + `${username}`);
    
  }
  unblockUser(username:String):Observable<object>{
    return this.http.get('http://localhost:8761/user/userDetailsUnblock/' + `${username}`);
    
  }
  blockMentor(username:String):Observable<object>{
    return this.http.get('http://localhost:8761/mentor/mentorDetailsBlock/' + `${username}`);
    
  }
  unblockMentor(username:String):Observable<object>{
    return this.http.get('http://localhost:8761/mentor/mentorDetailsUnblock/' + `${username}`);
    
  }
  createTechnology(technologies:object):Observable<object>{
    return this.http.post('http://localhost:8761/technology/technologies',technologies);
    
  }
  getTechnologies():Observable<Technologies>{
    return this.http.get<Technologies>('http://localhost:8761/technology/technologies');
  }
  createSkills(mentorSkills:object):Observable<object>{
    console.log(mentorSkills+"=-");
    return this.http.post('http://localhost:8761/mentorSkills/mentorSkills',mentorSkills);
  }
  getMentorSkills(firstName:String):Observable<MentorSkills>{
    return this.http.get<MentorSkills>('http://localhost:8761/mentorSkills/mentorSkills/'+ `${firstName}`);
  }
  
  deleteTechnology(techName:String) {
    return this.http.delete('http://localhost:8761/technology/technologies/' + `${techName}`);
  }



  startDate;
  endDate;
  firstName;
  username;
  //skills;
   skills=[];
}
 
  

  export class Mentor {
     firstName:String;
    username:String;
    password:String;
    fees:Number;
    courseName:String;
    commission:Number;
    status:String;
    totalFees:Number;
    years:Number;
    timings:String;
    isBlocked:String;
    
  }[];

 export class User {
  firstName:String;
username:String;
fee_status:Number;
password:String;
isBlocked:String;
}[];

export class MentorCalendar{
  startDate:String;
  endDate:String;
}[];

export class MentorSkills{
  skillId:Number;
  skills:String;
  firstName:String;
}

export class Technologies{
  techName:String;
  commission:Number;
}[];
