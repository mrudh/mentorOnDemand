import { Component, OnInit } from '@angular/core';
import { ValidationMentorService,Mentor,Technologies } from '../validation-mentor.service';
import { FormGroup, FormControl,Validators,FormBuilder } from '@angular/forms';
@Component({
  selector: 'app-display-tech-list',
  templateUrl: './display-tech-list.component.html',
  styleUrls: ['./display-tech-list.component.scss']
})
export class DisplayTechListComponent implements OnInit {

  technology:Technologies=new Technologies();
techForm: FormGroup;
i;
tech=[];
  constructor(private formBuilder: FormBuilder,private adminValidationService:ValidationMentorService) { }

  ngOnInit() {
   
    this.techForm = this.formBuilder.group({
      techName:['',[Validators.required]],
      commission:['',[Validators.required]]
  });
  this.adminValidationService.getTechnologies().subscribe((data) => {
    var index=0;
    for(this.i=0;this.i<Object.keys(data).length;this.i++){
      this.tech[index]=data[this.i];
      index++;
    }
 
})

}


get f() { return this.techForm.controls; }
  onSubmit(){
    this.technology=new Technologies();
    this.technology.techName=this.techForm.get('techName').value;
    this.technology.commission=this.techForm.get('commission').value;
    this.save();
    
  }
  save(){
    
    this.adminValidationService.createTechnology(this.technology).subscribe((data)=>
    this.adminValidationService.getTechnologies().subscribe((data) => {
      var index=0;
      for(this.i=0;this.i<Object.keys(data).length;this.i++){
        this.tech[index]=data[this.i];
        index++;
      }
   
  })
    );
  
   
}

deleteTech(event,techName) {
  this.adminValidationService.deleteTechnology(techName).subscribe((data)=> 
    this.ngOnInit()
  );
}
}