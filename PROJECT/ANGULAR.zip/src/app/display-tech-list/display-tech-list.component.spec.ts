import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayTechListComponent } from './display-tech-list.component';

describe('DisplayTechListComponent', () => {
  let component: DisplayTechListComponent;
  let fixture: ComponentFixture<DisplayTechListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisplayTechListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayTechListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
