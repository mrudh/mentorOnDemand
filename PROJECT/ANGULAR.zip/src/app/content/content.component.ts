import { Component, OnInit } from '@angular/core';
import { SearchresultsService } from '../searchresults.service';
import { FormControl,FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ValidationMentorService } from '../validation-mentor.service';
@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',

  styleUrls: ['./content.component.scss']
})
export class ContentComponent implements OnInit {
  myControl = new FormControl();
  options: string[] = ['Angular',  'Dotnet',  'Java','Python'];
 
  constructor(private route:ActivatedRoute,private router:Router,private searchService:SearchresultsService,
    private validationMentorService:ValidationMentorService) { }
searchForm;

  ngOnInit() {
    this.searchForm=new FormGroup({myControl:new FormControl("")});
  }
  OnClickSearch(data){
    this.myControl=data.myControl;
    this.searchService.searchTechnology(this.myControl,this.router);
    this.validationMentorService.startDate=this.searchForm.get('startDate').value;
    this.validationMentorService.endDate=this.searchForm.get('endDate').value;
   

  }

}
