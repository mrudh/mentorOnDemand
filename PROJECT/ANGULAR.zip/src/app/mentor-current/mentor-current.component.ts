import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-current',
  templateUrl: './mentor-current.component.html',
  styleUrls: ['./mentor-current.component.scss']
})
export class MentorCurrentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
