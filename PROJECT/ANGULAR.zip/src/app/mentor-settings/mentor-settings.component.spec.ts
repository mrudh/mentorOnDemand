import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorSettingsComponent } from './mentor-settings.component';

describe('MentorSettingsComponent', () => {
  let component: MentorSettingsComponent;
  let fixture: ComponentFixture<MentorSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
