import { Component, OnInit } from '@angular/core';
import { ValidationMentorService,MentorSkills,Technologies } from '../validation-mentor.service';
import { FormGroup, FormControl,Validators,FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-mentor-settings',
  templateUrl: './mentor-settings.component.html',
  styleUrls: ['./mentor-settings.component.scss']
})
export class MentorSettingsComponent implements OnInit {
  i;
  
  skills=[];
  mentorSkills:MentorSkills=new MentorSkills();
  skillForm: FormGroup;
  constructor(private formBuilder: FormBuilder,private route:Router,private validation:ValidationMentorService) { }

  ngOnInit() {
    this.skillForm = this.formBuilder.group({
      skills:['',[Validators.required]],
     
  });
  this.validation.getMentorSkills(this.validation.firstName).subscribe((data) =>{
    var index=0;
    for(this.i=0;this.i<Object.keys(data).length;this.i++){
      this.skills[index]=data[this.i];
      index++;
    }

  });
 
}

get f() { return this.skillForm.controls; }
  onSubmit(){
    //this.mentorSkills=new MentorSkills();
    this.mentorSkills.skills=this.skillForm.get('skills').value;
    console.log(this.mentorSkills.skills);
    this.mentorSkills.firstName=this.validation.username;
    this.save();
    this.route.navigate(['/mentor-my-profile']);
  }
 save(){
   this.validation.createSkills(this.mentorSkills).subscribe();
   //this.ngOnInit()
  
    
 
}
}
