import { Component, OnInit } from '@angular/core';
import { ValidationMentorService } from '../validation-mentor.service';
@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.scss']
})
export class MyProfileComponent implements OnInit {

  constructor( private validationUserService:ValidationMentorService) { }
user_name;
first_name;
  ngOnInit() {
    this.user_name=this.validationUserService.username;
  this.first_name=this.validationUserService.firstName;
  }

}
