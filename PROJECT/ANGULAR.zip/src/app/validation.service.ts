// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// @Injectable({
//   providedIn: 'root'
// })
// export class ValidationService {
// users=[];
//   constructor(  private http: HttpClient) { }
//   getUserDetails() {
//     return this.http.get('/assets/userCredentials.json');
//   }
// user_name;
// }
//   export interface Credentials{
//     name:String;
//     passw:String;
//     uname:String;
//   }

  

