import { TestBed } from '@angular/core/testing';

import { SearchresultsService } from './searchresults.service';

describe('SearchresultsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SearchresultsService = TestBed.get(SearchresultsService);
    expect(service).toBeTruthy();
  });
});
