import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validators,FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import {HttpClient} from '@angular/common/http';
import { ValidationMentorService } from '../validation-mentor.service';
import {Mentor,MentorCalendar,MentorSkills} from '../validation-mentor.service';
@Component({
  selector: 'app-mentor-signup',
  templateUrl: './mentor-signup.component.html',
  styleUrls: ['./mentor-signup.component.scss']
})
export class MentorSignupComponent implements OnInit {
  SignUpForm: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder,private router:Router,private http:HttpClient,private mentorService:ValidationMentorService) { }

  ngOnInit() {
    this.initsignUpForm();
  }
mentor:Mentor=new Mentor();
mentorCalendar:MentorCalendar=new MentorCalendar();
mentorSkills:MentorSkills=new MentorSkills();

  onSubmit() {
this.mentor=new Mentor();
this.mentor.username=this.SignUpForm.get('Email').value;
this.mentor.password=this.SignUpForm.get('Password').value;
this.mentor.courseName=this.SignUpForm.get('courseName').value;
this.mentor.firstName=this.SignUpForm.get('FirstName').value;
this.mentor.fees=this.SignUpForm.get('fees').value;
this.mentor.years=this.SignUpForm.get('years').value;
this.mentor.timings=this.SignUpForm.get('timings').value;
this.mentorCalendar=new MentorCalendar();
this.mentorCalendar.startDate=this.SignUpForm.get('startDate').value;
this.mentorCalendar.endDate=this.SignUpForm.get('endDate').value;

this.submitted = true;
this.save();
// this.saveMentor();
// this.saveMentorCalendar();
// this.saveMentorSkills();

    if(this.SignUpForm.valid)
      this.router.navigate(['/mentor-login'])
}
i;
  get f() { return this.SignUpForm.controls; }

// private baseUrl="http://localhost:8081";
// createMentor (mentor:object) :Observable<object> {
//   return this.http.post("${this.baseUrl}+addMentor",mentor);
// }
save(){
  this.mentorService.addMentorDetails(this.mentor).subscribe(data=>console.log(data),error=>console.log(error));
  this.mentorService.addCalendarDetails(this.mentorCalendar,this.mentor.username).subscribe(data=>console.log(data),error=>console.log(error));
}

// saveMentorSkills(){
// for(this.i=0;this.i<this.interests.length;this.i++){
//   this.mentorSkills.skillName=this.interests[this.i];
//   this.mentorService.addSkills(this.mentorSkills,this.mentor.username).subscribe(error=>console.log(error));
// }
// }


  private initsignUpForm() {
    this.SignUpForm =this.formBuilder.group({
      
      FirstName : new FormControl(null,Validators.required),
      LastName : new FormControl(null,Validators.required),
      courseName:new FormControl(null,Validators.required),
      Email: new FormControl('',[Validators.required,Validators.email]),
    Password : new FormControl('',[Validators.required,Validators.minLength(6)]),
     startDate: new FormControl(null,Validators.required),
     endDate: new FormControl(null,Validators.required),
     fees: new FormControl(null,Validators.required),
     years: new FormControl(null,Validators.required),
     timings: new FormControl(null,Validators.required),
    //  skills:['']
    });
}
// interests=[];

// onCheckboxClick(event,value) {
//   console.log(value);
//   if(event.target.checked){
//     console.log("pushed="+value);
//     this.interests.push(value);
//   }
//   if(!event.target.checked){
//     let index=this.interests.indexOf(value);
//     if(index>-1) {
//       this.interests.splice(index,1);
//     }
//   }
//   console.log("skills array =>" + JSON.stringify(this.interests,null,2));
// }

}