import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validators,FormBuilder, EmailValidator } from '@angular/forms';
import { ValidationAdminService } from '../validation-admin.service';
import {ACredentials} from '../validation-admin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.scss']
})
export class AdminLoginComponent implements OnInit {

  AdminLogInForm: FormGroup;
  submitted = false;

constructor(private formBuilder: FormBuilder, private validationAdminService:ValidationAdminService,private route:Router,) {

}
userDetails;
model:any={username:String,password:String,errorMessage:String,validStatus:Boolean}
ngOnInit() {
  this.initadminlogInForm();
 this.model.username="";
 this.model.password="";
 this.model.errorMessage="";
 this.model.invalidStatus=false;
}
onSubmit(){
  this.submitted=true;
  this.userDetails=this.validationAdminService.getAdminDetails().subscribe((data:ACredentials)=>{
    if(data[0].name==this.model.username && data[0].passw==this.model.password) {
      this.route.navigate(['/admin-navbar']);
    }
else {
        this.model.username="";
        this.model.password="";
        this.model.errorMessage="username or password is incorrect";
        this.model.invalidStatus=true;
}
});
}

get f() { return this.AdminLogInForm.controls; }

private initadminlogInForm() {
  this.AdminLogInForm =this.formBuilder.group({
    Email: new FormControl('',[Validators.required,Validators.email]),
    Password : new FormControl('',[Validators.required,Validators.minLength(4)])
  });
}
}