import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NavbarComponent } from './navbar/navbar.component';
import { ContentComponent } from './content/content.component';
import { LogInComponent } from './log-in/log-in.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { ContentLayoutComponent } from './layouts/content-layout/content-layout.component';
import { LogInLayoutComponent } from './layouts/log-in-layout/log-in-layout.component';
import { SignUpLayoutComponent } from './layouts/sign-up-layout/sign-up-layout.component';
// import { SearchResultsLayoutComponent } from './layouts/search-results-layout/search-results-layout.component';
// import { SearchResultsComponent } from './search-results/search-results.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { UserLayoutComponent } from './layouts/user-layout/user-layout.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { MyProfileLayoutComponent } from './layouts/my-profile-layout/my-profile-layout.component';
import { UserCurrentComponent } from './user-current/user-current.component';
import { UserCurrentLayoutComponent } from './layouts/user-current-layout/user-current-layout.component';
import { UserCompletedComponent } from './user-completed/user-completed.component';
import { UserCompletedLayoutComponent } from './layouts/user-completed-layout/user-completed-layout.component';
import { UserSettingsComponent } from './user-settings/user-settings.component';
import { UserSettingsLayoutComponent } from './layouts/user-settings-layout/user-settings-layout.component';
import { MentorLoginComponent } from './mentor-login/mentor-login.component';
import { MentorLoginLayoutComponent } from './layouts/mentor-login-layout/mentor-login-layout.component';
import { MentorProfileComponent } from './mentor-profile/mentor-profile.component';
import { MentorProfileLayoutComponent } from './layouts/mentor-profile-layout/mentor-profile-layout.component';
import { MentorMyProfileComponent } from './mentor-my-profile/mentor-my-profile.component';
import { MentorMyProfileLayoutComponent } from './layouts/mentor-my-profile-layout/mentor-my-profile-layout.component';
import { MentorCurrentComponent } from './mentor-current/mentor-current.component';
import { MentorCurrentLayoutComponent } from './layouts/mentor-current-layout/mentor-current-layout.component';
import { MentorCompletedComponent } from './mentor-completed/mentor-completed.component';
import { MentorCompletedLayoutComponent } from './layouts/mentor-completed-layout/mentor-completed-layout.component';
import { AdminNavbarComponent } from './admin-navbar/admin-navbar.component';
import { AdminNavbarLayoutComponent } from './layouts/admin-navbar-layout/admin-navbar-layout.component';
import { AdminLoginLayoutComponent } from './layouts/admin-login-layout/admin-login-layout.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { EditPermissionComponent } from './edit-permission/edit-permission.component';
import { AdminEditPermissionLayoutComponent } from './layouts/admin-edit-permission-layout/admin-edit-permission-layout.component';
import { SearchresultsComponent } from './searchresults/searchresults.component';
import { SearchresultsLayoutComponent } from './layouts/searchresults-layout/searchresults-layout.component';
import { CreditcardComponent } from './creditcard/creditcard.component';
import { CreditLayoutComponent } from './layouts/credit-layout/credit-layout.component';
import { AdminPaymentsLayoutComponent } from './layouts/admin-payments-layout/admin-payments-layout.component';
import { AdminPaymentsComponent } from './admin-payments/admin-payments.component';
import { AdminDisplayReportsComponent } from './admin-display-reports/admin-display-reports.component';
import { AdminDisplayReportsLayoutComponent } from './layouts/admin-display-reports-layout/admin-display-reports-layout.component';
import { MentorSettingsComponent } from './mentor-settings/mentor-settings.component';
import { MentorSettingsLayoutComponent } from './layouts/mentor-settings-layout/mentor-settings-layout.component';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { MentorSignupLayoutComponent } from './layouts/mentor-signup-layout/mentor-signup-layout.component';
import { DisplayTechListComponent } from './display-tech-list/display-tech-list.component';
const routes: Routes = [{ path: 'display', component: DisplayTechListComponent },
  { 
    path: '', 
    component: ContentLayoutComponent ,
  children: [
    {
      path:'',
      component:ContentComponent
    }
  ]
  },
{
  path:'',
  component: LogInLayoutComponent,
  children: [
    {
      path:'log-in',
      component:LogInComponent
    }
  ]
},
{
  path:'',
  component: SignUpLayoutComponent,
  children: [
    {
      path:'sign-up',
      component:SignUpComponent
    }
  ]
},


{
  path:'',
  component: UserLayoutComponent,
  children: [
    {
      path:'user',
      component:UserProfileComponent
    }
  ]
},

{
  path:'',
  component: MyProfileLayoutComponent,
  children: [
    {
      path:'my-profile',
      component:MyProfileComponent
    }
  ]
},

{
  path:'',
  component: UserCurrentLayoutComponent,
  children: [
    {
      path:'user-current',
      component:UserCurrentComponent
    }
  ]
},
{
  path:'',
  component: UserCompletedLayoutComponent,
  children: [
    {
      path:'user-completed',
      component:UserCompletedComponent
    }
  ]
},
{
  path:'',
  component: UserSettingsLayoutComponent,
  children: [
    {
      path:'user-settings',
      component:UserSettingsComponent
    }
  ]
},
{
  path:'',
  component: MentorLoginLayoutComponent,
  children: [
    {
      path:'mentor-login',
      component:MentorLoginComponent
    }
  ]
},
{
  path:'',
  component: MentorProfileLayoutComponent,
  children: [
    {
      path:'mentor-profile',
      component:MentorProfileComponent
    }
  ]
},
{
  path:'',
  component: MentorMyProfileLayoutComponent, 
  children: [
    {
      path:'mentor-my-profile',
      component:MentorMyProfileComponent  
    }
  ]
},
{
  path:'',
  component: MentorCurrentLayoutComponent,
  children: [
    {
      path:'mentor-current',
      component: MentorCurrentComponent
    }
  ]
},
{
  path:'',
  component: MentorCompletedLayoutComponent,
  children: [
    {
      path:'mentor-completed',
      component: MentorCompletedComponent
    }
  ]
},
{
  path:'',
  component: AdminNavbarLayoutComponent,
  children: [
    {
      path:'admin-navbar',
      component: AdminNavbarComponent
    }
  ]
},
{
  path:'',
  component: AdminLoginLayoutComponent,
  children: [
    {
      path:'admin-login',
      component: AdminLoginComponent
    }
  ]
},
{
  path:'',
  component: AdminEditPermissionLayoutComponent,
  children: [
    {
      path:'edit-permission',
      component: EditPermissionComponent
    }
  ]
},
{
  path:'',
  component: SearchresultsLayoutComponent,
  children: [
    {
      path:'techs/:techId',
      component: SearchresultsComponent
    }
  ]
},
{
  path:'',
  component: CreditLayoutComponent,
  children: [
    {
      path:'credit',
      component: CreditcardComponent 
    }
  ]
},
{
  path:'',
  component: AdminPaymentsLayoutComponent,
  children: [
    {
      path:'admin-payments',
      component: AdminPaymentsComponent 
    }
  ]
},
{
  path:'',
  component: AdminDisplayReportsLayoutComponent,
  children: [
    {
      path:'admin-display-reports',
      component:AdminDisplayReportsComponent
    }
  ]
},
{
  path:'',
  component: MentorSettingsLayoutComponent,
  children: [
    {
      path:'mentor-settings',
      component:MentorSettingsComponent
    }
  ]
},
{
  path:'',
  component: MentorSignupLayoutComponent,
  children: [
    {
      path:'mentor-signup',
      component:MentorSignupComponent
    }
  ]
},
{
  path: '**', redirectTo:''
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
