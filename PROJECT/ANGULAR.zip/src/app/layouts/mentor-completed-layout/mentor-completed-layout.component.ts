import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-completed-layout',
  template: `
   <router-outlet></router-outlet>
  `,
  styles: []
})
export class MentorCompletedLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
