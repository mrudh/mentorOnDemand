import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorCompletedLayoutComponent } from './mentor-completed-layout.component';

describe('MentorCompletedLayoutComponent', () => {
  let component: MentorCompletedLayoutComponent;
  let fixture: ComponentFixture<MentorCompletedLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorCompletedLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorCompletedLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
