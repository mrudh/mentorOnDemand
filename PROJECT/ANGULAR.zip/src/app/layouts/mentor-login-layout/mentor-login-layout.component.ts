import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-login-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class MentorLoginLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
