import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorLoginLayoutComponent } from './mentor-login-layout.component';

describe('MentorLoginLayoutComponent', () => {
  let component: MentorLoginLayoutComponent;
  let fixture: ComponentFixture<MentorLoginLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorLoginLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorLoginLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
