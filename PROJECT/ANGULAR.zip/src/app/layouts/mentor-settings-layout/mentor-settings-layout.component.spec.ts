import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorSettingsLayoutComponent } from './mentor-settings-layout.component';

describe('MentorSettingsLayoutComponent', () => {
  let component: MentorSettingsLayoutComponent;
  let fixture: ComponentFixture<MentorSettingsLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorSettingsLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorSettingsLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
