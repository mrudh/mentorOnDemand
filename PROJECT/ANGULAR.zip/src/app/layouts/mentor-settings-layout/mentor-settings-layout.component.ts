import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-settings-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class MentorSettingsLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
