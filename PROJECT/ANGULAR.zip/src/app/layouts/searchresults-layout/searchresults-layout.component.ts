import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchresults-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class SearchresultsLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
