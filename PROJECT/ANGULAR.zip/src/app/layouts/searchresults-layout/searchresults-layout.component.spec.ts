import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchresultsLayoutComponent } from './searchresults-layout.component';

describe('SearchresultsLayoutComponent', () => {
  let component: SearchresultsLayoutComponent;
  let fixture: ComponentFixture<SearchresultsLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchresultsLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchresultsLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
