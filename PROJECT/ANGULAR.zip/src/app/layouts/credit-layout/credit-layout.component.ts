import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-credit-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class CreditLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
