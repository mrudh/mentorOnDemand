import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-login-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class AdminLoginLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
