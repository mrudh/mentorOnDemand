import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyProfileLayoutComponent } from './my-profile-layout.component';

describe('MyProfileLayoutComponent', () => {
  let component: MyProfileLayoutComponent;
  let fixture: ComponentFixture<MyProfileLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyProfileLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyProfileLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
