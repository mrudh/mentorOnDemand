import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-profile-layout',
  template: `
  <router-outlet></router-outlet>
  `,
  styles: []
})
export class MyProfileLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
