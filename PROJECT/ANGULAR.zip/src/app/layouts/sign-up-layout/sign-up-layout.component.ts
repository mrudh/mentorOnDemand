import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sign-up-layout',
  template: `
  <router-outlet></router-outlet>
  `,
  styles: []
})
export class SignUpLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}