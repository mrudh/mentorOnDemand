import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserCurrentLayoutComponent } from './user-current-layout.component';

describe('UserCurrentLayoutComponent', () => {
  let component: UserCurrentLayoutComponent;
  let fixture: ComponentFixture<UserCurrentLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserCurrentLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserCurrentLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
