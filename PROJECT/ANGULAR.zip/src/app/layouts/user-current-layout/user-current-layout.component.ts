import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-current-layout',
  template: `
  <router-outlet></router-outlet>
  `,
  styles: []
})
export class UserCurrentLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
