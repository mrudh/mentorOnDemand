import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminDisplayReportsLayoutComponent } from './admin-display-reports-layout.component';

describe('AdminDisplayReportsLayoutComponent', () => {
  let component: AdminDisplayReportsLayoutComponent;
  let fixture: ComponentFixture<AdminDisplayReportsLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminDisplayReportsLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminDisplayReportsLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
