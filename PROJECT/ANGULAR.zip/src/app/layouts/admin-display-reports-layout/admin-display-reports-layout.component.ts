import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-display-reports-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class AdminDisplayReportsLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
