import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-layout',
  template: `
    <p>
      footer-layout works!
    </p>
  `,
  styles: []
})
export class FooterLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
