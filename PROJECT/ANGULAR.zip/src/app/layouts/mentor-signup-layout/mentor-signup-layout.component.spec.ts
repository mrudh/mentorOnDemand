import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorSignupLayoutComponent } from './mentor-signup-layout.component';

describe('MentorSignupLayoutComponent', () => {
  let component: MentorSignupLayoutComponent;
  let fixture: ComponentFixture<MentorSignupLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorSignupLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorSignupLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
