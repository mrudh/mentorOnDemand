import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-signup-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class MentorSignupLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
