import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-layout',
  template: `
  <router-outlet></router-outlet>
  `,
  styles: []
})
export class UserLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
