import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorMyProfileLayoutComponent } from './mentor-my-profile-layout.component';

describe('MentorMyProfileLayoutComponent', () => {
  let component: MentorMyProfileLayoutComponent;
  let fixture: ComponentFixture<MentorMyProfileLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorMyProfileLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorMyProfileLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
