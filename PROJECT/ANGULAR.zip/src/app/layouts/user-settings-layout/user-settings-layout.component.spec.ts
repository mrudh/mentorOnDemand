import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserSettingsLayoutComponent } from './user-settings-layout.component';

describe('UserSettingsLayoutComponent', () => {
  let component: UserSettingsLayoutComponent;
  let fixture: ComponentFixture<UserSettingsLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserSettingsLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserSettingsLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
