import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-settings-layout',
  template: `
  <router-outlet></router-outlet>
  `,
  styles: []
})
export class UserSettingsLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
