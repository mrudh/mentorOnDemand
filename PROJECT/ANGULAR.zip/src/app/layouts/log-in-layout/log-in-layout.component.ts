import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-log-in-layout',
  template: `
  <router-outlet></router-outlet>
  `,
  styles: []
})
export class LogInLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}