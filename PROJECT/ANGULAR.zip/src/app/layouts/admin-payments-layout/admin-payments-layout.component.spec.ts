import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminPaymentsLayoutComponent } from './admin-payments-layout.component';

describe('AdminPaymentsLayoutComponent', () => {
  let component: AdminPaymentsLayoutComponent;
  let fixture: ComponentFixture<AdminPaymentsLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminPaymentsLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminPaymentsLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
