import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-payments-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class AdminPaymentsLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
