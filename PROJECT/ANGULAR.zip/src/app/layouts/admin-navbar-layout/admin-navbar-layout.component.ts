import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-navbar-layout',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class AdminNavbarLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
