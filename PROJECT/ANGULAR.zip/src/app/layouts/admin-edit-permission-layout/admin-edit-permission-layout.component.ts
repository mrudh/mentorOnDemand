import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-edit-permission-layout',
  template: `
  <router-outlet></router-outlet>
  `,
  styles: []
})
export class AdminEditPermissionLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
