import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminEditPermissionLayoutComponent } from './admin-edit-permission-layout.component';

describe('AdminEditPermissionLayoutComponent', () => {
  let component: AdminEditPermissionLayoutComponent;
  let fixture: ComponentFixture<AdminEditPermissionLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminEditPermissionLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminEditPermissionLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
