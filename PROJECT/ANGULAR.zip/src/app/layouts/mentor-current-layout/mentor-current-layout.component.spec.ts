import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorCurrentLayoutComponent } from './mentor-current-layout.component';

describe('MentorCurrentLayoutComponent', () => {
  let component: MentorCurrentLayoutComponent;
  let fixture: ComponentFixture<MentorCurrentLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorCurrentLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorCurrentLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
