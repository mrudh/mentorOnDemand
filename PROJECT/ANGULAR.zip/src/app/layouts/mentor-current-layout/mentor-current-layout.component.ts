import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-current-layout',
  template: `
   <router-outlet></router-outlet>
  `,
  styles: []
})
export class MentorCurrentLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
