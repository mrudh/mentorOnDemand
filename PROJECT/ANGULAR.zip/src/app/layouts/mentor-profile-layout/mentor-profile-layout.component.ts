import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-profile-layout',
  template: `
  <router-outlet></router-outlet>
  `,
  styles: []
})
export class MentorProfileLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
