import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-completed-layout',
  template: `
  <router-outlet></router-outlet>
  `,
  styles: []
})
export class UserCompletedLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
