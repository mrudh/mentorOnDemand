package com.project.MentorOnDemand.Trainees;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="UserDetails")
public class UserDetails {

	@Id

	private String username;
	private String feeStatus;
	private String password;
	private String firstName;
	private String isBlocked="no";


	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getFeesStatus() {
		return feeStatus;
	}
	public void setFeeStatus(String feesStatus) {
		this.feeStatus = feeStatus;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public String getFeeStatus() {
		return feeStatus;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getIsBlocked() {
		return isBlocked;
	}

	public void setIsBlocked(String isBlocked) {
		this.isBlocked = isBlocked;
	}
}
