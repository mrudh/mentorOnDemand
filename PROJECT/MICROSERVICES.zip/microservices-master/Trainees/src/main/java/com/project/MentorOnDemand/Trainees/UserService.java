package com.project.MentorOnDemand.Trainees;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
public class UserService {

	@Autowired
	UserRepository userRepository;

	public void addUser(UserDetails userDetails) {
		// TODO Auto-generated method stub
		userDetails.setFeeStatus("Paid");
		userRepository.save(userDetails);
	}

	public List<UserDetails> getUserDetails() {
		List<UserDetails> usersList=new ArrayList<>();
		userRepository.findAll().forEach(usersList::add);
		return usersList;
	}

	public void blockUser(String id) {
		UserDetails userDetails;
		userDetails=userRepository.findById(id).get();
		userDetails.setIsBlocked("yes");
		userRepository.save(userDetails);
	}

	public void unblockUser(String id) {
		UserDetails userDetails;
		userDetails=userRepository.findById(id).get();
		userDetails.setIsBlocked("no");
		userRepository.save(userDetails);
	}
}
