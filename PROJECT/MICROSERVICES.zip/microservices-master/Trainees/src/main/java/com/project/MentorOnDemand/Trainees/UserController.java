package com.project.MentorOnDemand.Trainees;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class UserController {

    @Autowired
    private UserService userService;

    @RequestMapping("/usersList")
    public List<UserDetails> getUserDetails() {
        return userService.getUserDetails();
    }

    @RequestMapping(method= RequestMethod.POST,value="/addUser")
    public void addUser(@RequestBody UserDetails userDetails) {
        userService.addUser(userDetails);
    }

    @RequestMapping(method=RequestMethod.GET,value="/userDetailsBlock/{id}")
    public void blockUser(@PathVariable String id) {
        userService.blockUser(id);
    }

    @RequestMapping(method=RequestMethod.GET,value="/userDetailsUnblock/{id}")
    public void unblockUser(@PathVariable String id){
        userService.unblockUser(id);
    }


}
