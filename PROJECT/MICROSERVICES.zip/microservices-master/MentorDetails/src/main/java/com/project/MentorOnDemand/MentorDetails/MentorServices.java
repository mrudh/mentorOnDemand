package com.project.MentorOnDemand.MentorDetails;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;


@Service
public class MentorServices {

	@Autowired
	private MentorDetailsRepository mentorDetailsRepository;

	public List<MentorDetails> getMentorDetails() {
		List<MentorDetails> mentorsList=new ArrayList<>();
		mentorDetailsRepository.findAll().forEach(mentorsList::add);
		return mentorsList;
	}


	public void addMentor(MentorDetails mentorDetails) {
		// TODO Auto-generated method stub
		Double commission=mentorDetails.getFees()*(0.278);
		 BigDecimal bd = new BigDecimal(commission).setScale(2, RoundingMode.HALF_UP);
	        double comm = bd.doubleValue();
		mentorDetails.setStatus("No");
		mentorDetails.setCommission(comm);
		mentorDetails.setTotalFees(comm+mentorDetails.getFees());
		Boolean isPresent=false;
		ArrayList<String> usernameList= mentorDetailsRepository.findAllUserNames();
		if(usernameList.isEmpty()){
			mentorDetailsRepository.save(mentorDetails);
		}else {
			for (int i = 0; i < usernameList.size(); i++) {
				if (usernameList.contains(mentorDetails.getUsername())) {
					isPresent = true;
					throw new DataIntegrityViolationException("already exists");
					//break;
				} else {
					isPresent = false;
				}
			}
			if (isPresent == false) {
				mentorDetailsRepository.save(mentorDetails);
			}
		}
	}


	public MentorDetails getMentor(String username) {
		MentorDetails mentorDetails=mentorDetailsRepository.findById(username).get();
		return mentorDetails;
	}

	public void blockMentor(String id) {
		MentorDetails mentorDetails;
		mentorDetails=mentorDetailsRepository.findById(id).get();
		mentorDetails.setIsBlocked("yes");
		mentorDetailsRepository.save(mentorDetails);
	}

	public void unblockMentor(String id) {
		MentorDetails mentorDetails;
		mentorDetails=mentorDetailsRepository.findById(id).get();
		mentorDetails.setIsBlocked("no");
		mentorDetailsRepository.save(mentorDetails);
	}



//	public void addCalendar(MentorCalendar mentorCalendar, String username) {
//		MentorDetails mentorDetails=new MentorDetails();
//		mentorDetails=mentorDetailsRepository.findById(username).get();
//		List<MentorDetails>mentorDetailsList=new ArrayList<MentorDetails>();
//		mentorDetailsList.add(mentorDetails);
//		mentorCalendar.setMenDetailsList(mentorDetailsList);
//	}
}
