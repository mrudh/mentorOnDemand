package com.project.MentorOnDemand.MentorDetails;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name="mentorCalendar")
public class MentorCalendar {
	

	@Id @GeneratedValue(strategy = GenerationType.TABLE) 
	private Integer calendarDate;
	private Date startDate;
	private Date endDate;

	public Integer getCalendarDate() {
		return calendarDate;
	}

	public void setCalendarDate(Integer calendarDate) {
		this.calendarDate = calendarDate;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
}
