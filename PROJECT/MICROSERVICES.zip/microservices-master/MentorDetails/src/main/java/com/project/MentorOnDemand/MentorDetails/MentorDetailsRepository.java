package com.project.MentorOnDemand.MentorDetails;


import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;


public interface MentorDetailsRepository extends CrudRepository<MentorDetails, String> {

	@Query(value = "SELECT username from MentorDetails")
    ArrayList<String> findAllUserNames();

	@Query(value="SELECT commission from Mentor_details where username= :user",nativeQuery = true)
    ArrayList<String> findAllCommission(@Param(value = "user") String  user);

}
