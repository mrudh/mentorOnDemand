package com.project.MentorOnDemand.MentorDetails;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class MentorDetailsController {
    @Autowired
    MentorServices mentorServices;

    @RequestMapping("/mentorsList")
    public List<MentorDetails> getMentorDetails() {
        return mentorServices.getMentorDetails();
    }

    @RequestMapping(value="/getMentor/{username}")
    public MentorDetails getMentor(@PathVariable(value="username") String userName){
        MentorDetails mentorDetails=mentorServices.getMentor(userName);
        return mentorDetails;
    }
    @RequestMapping(method = RequestMethod.POST,value="/addMentor")
    public void addMentor(@RequestBody MentorDetails mentorDetails) {
        mentorServices.addMentor(mentorDetails);
       // mentorServices.addCalendar();
    }
    @RequestMapping(method=RequestMethod.GET,value="/mentorDetailsBlock/{id}")
    public void blockMentor(@PathVariable String id){
        mentorServices.blockMentor(id);
    }
    @RequestMapping(method=RequestMethod.GET,value="/mentorDetailsUnblock/{id}")
    public void unblockMentor(@PathVariable String id){
        mentorServices.unblockMentor(id);
    }





}
