package com.project.MentorOnDemand.MentorCalendar;

import javax.persistence.*;
import java.sql.Date;
import java.util.List;

@Entity
@Table(name="mentorCalendar")
public class MentorCalendar {
	

	@Id @GeneratedValue(strategy = GenerationType.TABLE) 
	private Integer calendarDate;
	private Date startDate;
	private Date endDate;
	private String courseName;

	public Integer getCalendarDate() {
		return calendarDate;
	}

	public void setCalendarDate(Integer calendarDate) {
		this.calendarDate = calendarDate;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
}
