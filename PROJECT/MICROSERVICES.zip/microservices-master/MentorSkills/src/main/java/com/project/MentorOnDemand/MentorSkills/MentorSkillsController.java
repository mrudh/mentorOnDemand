package com.project.MentorOnDemand.MentorSkills;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class MentorSkillsController {

    @Autowired
    MentorSkillsServices mentorSkillsServices;

//    @RequestMapping(method = RequestMethod.POST,value="/addSkill/{userName}")
//    public void addCalendar(@RequestBody MentorSkills mentorSkills, @PathVariable String username) {
//        mentorSkillsServices.addSkills(mentorSkills,username);
//    }

    @RequestMapping("/mentorSkills/{firstName}")
    public List<MentorSkills> getSkills(@PathVariable String firstName) {
        return mentorSkillsServices.getSkills(firstName);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/mentorSkills")
    public void addMentorSkills(@RequestBody MentorSkills mentorskills) {
        mentorSkillsServices.setSkills(mentorskills);
    }

}
