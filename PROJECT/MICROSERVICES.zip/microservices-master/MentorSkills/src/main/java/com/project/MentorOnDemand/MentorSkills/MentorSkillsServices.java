package com.project.MentorOnDemand.MentorSkills;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class MentorSkillsServices {

	@Autowired
	MentorSkillsRepository mentorSkillsRepository;
	

	
//	public void addSkills(MentorSkills mentorSkills,String username) {
//
//		//MentorDetails mentorDetails=new MentorDetails();
//		System.out.println("details="+username);
//		//MentorDetails mentorDetails=mentorSkillsRepository.findMentorDetails(userName);
//		//mentorSkills.setMentorDetails(mentorDetails);
//
//		mentorSkillsRepository.save(mentorSkills);
//		int skillId=mentorSkills.getSkillId();
//		System.out.println("id="+skillId);
//		mentorSkillsRepository.updateMentorName(username,skillId);
//	}


	public List<MentorSkills> getSkills(String id) {
		List<MentorSkills> ls;
		ls=mentorSkillsRepository.findSkills(id);
		return ls;
	}

	public void setSkills(MentorSkills mentorskills) {
		mentorSkillsRepository.save(mentorskills);
	}
}
