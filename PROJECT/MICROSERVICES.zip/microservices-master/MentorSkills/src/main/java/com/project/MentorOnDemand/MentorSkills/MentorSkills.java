package com.project.MentorOnDemand.MentorSkills;

import javax.persistence.*;

@Entity
@Table(name="mentorSkills")
public class MentorSkills {

	@Id @GeneratedValue(strategy = GenerationType.TABLE)
	private int skillId;
	private String skills;
	private String firstName;

	public int getSkillId() {
		return skillId;
	}

	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	//	@ManyToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name = "mentor_name")
//	private MentorDetails mentorDetails;
//
//	public MentorDetails getMentorDetails() {
//		return mentorDetails;
//	}
//	public void setMentorDetails(MentorDetails mentorDetails) {
//		this.mentorDetails = mentorDetails;
//	}
//
//
	
	
}
