package com.project.MentorOnDemand.Technologies;

import org.springframework.data.repository.CrudRepository;

public interface TechRepository extends CrudRepository<Technologies, String> {
}
