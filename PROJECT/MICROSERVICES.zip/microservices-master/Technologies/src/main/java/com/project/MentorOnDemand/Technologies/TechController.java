package com.project.MentorOnDemand.Technologies;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins="http://localhost:4200")

public class TechController {

    @Autowired
    private TechService techService;

    @RequestMapping("/technologies")
    public List<Technologies> getTechnologies() {
        return techService.getTechnologies();
    }

    @RequestMapping(method = RequestMethod.POST, value = "/technologies")
    public void addUserDetails(@RequestBody Technologies technologies) {
        techService.setTechnologies(technologies);
    }

    @RequestMapping(method=RequestMethod.DELETE,value="/technologies/{id}")
    public void deleteTraining(@PathVariable String id){
        techService.deleteTraining(id);
    }
}
