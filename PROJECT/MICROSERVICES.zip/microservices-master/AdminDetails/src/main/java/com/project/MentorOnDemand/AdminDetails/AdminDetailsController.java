package com.project.MentorOnDemand.AdminDetails;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class AdminDetailsController {
    @Autowired
    AdminDetailsService adminDetailsService;

    @Autowired
    private RestTemplate restTemplate;
    @RequestMapping("/adminCourses")
    public AdminDetailsService getAdminCourses() {
        return adminDetailsService;
    }

    @PostMapping("/addMentor")
    public void addMentor(@RequestBody MentorDetails mentorDetails) {
        System.out.println("helllo");
        MentorDetails  mentDetails=restTemplate.postForObject("http://localhost:9096/addMentor",mentorDetails,MentorDetails.class);

        adminDetailsService.addCourse(mentorDetails);
    }

    @PostMapping("/addCalendar/{username}")
    public void addCalendar(@RequestBody MentorCalendar mentorCalendar,@PathVariable (value="username") String username) throws Exception {
        adminDetailsService.checkForUser(username);
        MentorCalendar mentCalendar=restTemplate.postForObject("http://localhost:9097/addMentor/addCalendar/"+username,mentorCalendar,MentorCalendar.class);
    }

    @PostMapping("/addSkill/{username}")
    public void addSkill(@RequestBody MentorSkills mentorSkill,@PathVariable(value="userName") String userName) throws Exception {
        System.out.println("name="+userName);
        adminDetailsService.checkForUser(userName);
        restTemplate.postForObject("http://localhost:9098/addSkill/"+userName,mentorSkill,MentorSkills.class);
    }

    @PostMapping("/addTraining/{userName}")
    public void addTraining(@RequestBody Trainings trainings,@PathVariable(value = "username") String username) throws Exception {
        adminDetailsService.checkForUser(username);
        restTemplate.postForObject("http://localhost:9099/addTrainings/"+username,trainings,Trainings.class);
    }

    @PostMapping("/addTrainee")
    public void addTrainee(@RequestBody UserDetails traineesDetails){
        restTemplate.postForObject("http://localhost:9100/addUser",traineesDetails,UserDetails.class);
    }


}
