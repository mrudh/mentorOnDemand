package com.project.MentorOnDemand.AdminDetails;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="MentorDetails")
public class MentorDetails {

	@Id @Column(unique = true)
	private String username;	//email
	private String courseName;
	private Double fees;
	private Double commission;
	private String status;
	private Double totalFees;
	private String password;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public Double getFees() {
		return fees;
	}

	public void setFees(Double fees) {
		this.fees = fees;
	}

	public Double getCommission() {
		return commission;
	}

	public void setCommission(Double commission) {
		this.commission = commission;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Double getTotalFees() {
		return totalFees;
	}

	public void setTotalFees(Double totalFees) {
		this.totalFees = totalFees;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	//@ManyToMany(cascade = CascadeType.ALL)
//private Collection<Trainings> trainings;
//
//public Collection<Trainings> getTrainings() {
//	return trainings;
//}
//public void setTrainings(Collection<Trainings> trainings) {
//	this.trainings = trainings;
//}



	public MentorDetails() {

	}
	
	
}
