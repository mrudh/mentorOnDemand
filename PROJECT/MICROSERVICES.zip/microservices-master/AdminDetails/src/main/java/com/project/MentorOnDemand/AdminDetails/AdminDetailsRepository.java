package com.project.MentorOnDemand.AdminDetails;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashSet;

public interface AdminDetailsRepository extends CrudRepository<AdminDetails,String> {

    @Query(value="SELECT courseName from AdminDetails")
    LinkedHashSet<String> findAllCourses();

    @Transactional
    @Query(value="select Count(username) from MentorDetailsDatabase.mentor_details where course_name=?1",nativeQuery = true)
    int findCount(String cname);

    @Modifying
    @Transactional
    @Query(value="UPDATE admin_details SET num_mentors=?2 WHERE course_name=?1",nativeQuery = true)
    int updateCount(String cname, int count);

    @Transactional
    @Query(value="select course_name from MentorDetailsDatabase.mentor_details where username=?1",nativeQuery = true)
    String findCourse(String username);

    @Transactional
    @Query(value="select username from MentorDetailsDatabase.mentor_details where username=?1",nativeQuery = true)
    String checkForUser(String username);

    @Transactional
    @Query(value="Select username from TraineeDatabase.user_details WHERE username=?1",nativeQuery = true)
    String checkForTrainee(String username);
}
