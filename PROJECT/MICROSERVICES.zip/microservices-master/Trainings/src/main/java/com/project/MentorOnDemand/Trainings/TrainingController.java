package com.project.MentorOnDemand.Trainings;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class TrainingController {
    @Autowired
    TrainingServices trainingServices;

    @RequestMapping(method = RequestMethod.POST,value="/addTrainings/{username}")
    public void addCalendar(@RequestBody Trainings trainings, @PathVariable String username) {
        trainingServices.addTrainings(trainings,username);
    }
}
